
# Oka Boot (Memecoin Alert Bot)

This bot monitors memecoin prices on Binance Testnet and sends alerts to a Telegram channel.

## Setup
1. Add your API keys and Telegram bot token as environment variables:
   - BINANCE_API_KEY
   - BINANCE_API_SECRET
   - TELEGRAM_BOT_TOKEN
   - TELEGRAM_CHAT_ID
2. Deploy to Render or run locally.

## Deployment
Use the `Procfile` for Render worker configuration.
