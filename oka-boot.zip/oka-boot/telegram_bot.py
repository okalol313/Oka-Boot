
import os
import telegram

bot = telegram.Bot(token=os.getenv('TELEGRAM_BOT_TOKEN'))
chat_id = os.getenv('TELEGRAM_CHAT_ID')

def notify(msg: str):
    bot.send_message(chat_id=chat_id, text=msg)
